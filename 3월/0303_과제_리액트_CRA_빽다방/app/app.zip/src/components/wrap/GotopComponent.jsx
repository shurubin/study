import React from 'react';

function GotopComponent(){
    return (
        <div id="gotop">
            <a href="#wrap"></a>
        </div>
    );
};

export default GotopComponent;