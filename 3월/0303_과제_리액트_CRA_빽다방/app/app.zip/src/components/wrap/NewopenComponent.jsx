import React from 'react';

function NewopenComponent(){
    return (
        <div className="newopen">
            <a href="https://start.theborn.co.kr/briefing.php" className="up"></a>
            <a href="https://start.theborn.co.kr/inquiry.php" className="down"></a>
        </div>
    );
};

export default NewopenComponent;