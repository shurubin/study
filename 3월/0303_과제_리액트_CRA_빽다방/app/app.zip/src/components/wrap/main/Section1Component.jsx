import React from 'react';

function Section1Component(){
    return (
        <div id="section1">
            <div className="container">
                <div className="slide-container">
                    <div className="slide-view">
                        <ul className="slide-wrap">
                            <li className="slide slide4"></li>
                            <li className="slide slide1"></li>
                            <li className="slide slide2"></li>
                            <li className="slide slide3"></li>
                            <li className="slide slide4"></li>
                            <li className="slide slide1"></li>
                        </ul>


                    </div>

                </div>
                
                <div className="pagenation">
                    <span>
                        <a href="#!" className="page btn1"></a>
                        <a href="#!" className="page btn2"></a>
                        <a href="#!" className="page btn3"></a>
                        <a href="#!" className="page btn4"></a>
                    </span>

                </div>
            </div>
        </div>
    );
};

export default Section1Component;