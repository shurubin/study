import React from 'react';

function Section6Component(){
    return (
        <div id="section6">
            <div className="text-box">
                <div className="text-box-gap">
                    <h3>PAIK’S COFFEE SNS</h3>
                    <h4>#빽다방&nbsp;&nbsp;#빽다방신메뉴&nbsp;&nbsp;#빽다방이벤트</h4>
                    <span><h5>.</h5></span>
                    <div className="sixsns">
                        <i><img src="./img/facebook-ico.png" alt=""/></i>
                        <i><img src="./img/insta-ico.png" alt=""/></i>
                    </div>
                </div>
            </div>            
        </div>
    );
};

export default Section6Component;