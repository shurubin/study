import React from 'react';

function Section3Component(){
    return (
        <div id="section3">
            <div className="text-box">
                <h2>fresh<br/>coffee</h2>
                <h5>.</h5>
                <h3>신선한 뉴크롭 원두를 사용하여<br/>추출한 커피메뉴!</h3>
                <span className="plus-btn"><a href="#!"></a></span>
            </div>


        </div>
    );
};

export default Section3Component;