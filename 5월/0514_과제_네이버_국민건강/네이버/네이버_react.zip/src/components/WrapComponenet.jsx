import React from 'react';
import Main1Component from './wrap/Main1Component';


export default function WrapComponenet(){
    return (       
        <div id='wrap'>           
            <Main1Component/>
        </div>
    );
};



