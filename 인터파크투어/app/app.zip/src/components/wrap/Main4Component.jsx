import React from 'react';

export default function Main4Component(){
    return (
        <div>
            <h1>main4</h1>
        </div>
    );
};