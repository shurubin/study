import React from 'react';

export default function Main3Component(){
    return (
        <div>
            <h1>main3</h1>
        </div>
    );
};