import React from 'react';

export default function Main5Component(){
    return (
        <div>
            <h1>main5</h1>
        </div>
    );
};