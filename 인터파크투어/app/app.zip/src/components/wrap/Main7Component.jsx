import React from 'react';

export default function Main7Component(){
    return (
        <div>
            <h1>main7</h1>
        </div>
    );
};