import React from 'react';

export default function Main1Component(){
    return (
        <div>
            <h1>main1</h1>
        </div>
    );
};