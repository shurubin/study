import React from 'react';

export default function HeaderComponent(){
    return (
        <div>
            <h1>header</h1>
        </div>
    );
};