import React from 'react';

export default function FooterComponent(){
    return (
        <div>
            <h1>footer</h1>
        </div>
    );
};