import React from 'react';

export default function Main8Component(){
    return (
        <div>
            <h1>main8</h1>
        </div>
    );
};