import React from 'react';

export default function Main2Component(){
    return (
        <div>
            <h1>main2</h1>
        </div>
    );
};